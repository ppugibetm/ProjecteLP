#pragma once
#include "pch.h"
#include "Util.h"
#include <iostream>
#include "CamiSolucio.h"
#include <vector>
#include <list>

using namespace std;

class Graf {
public:
	Graf() { m_numNodes = 0, m_numArestes = 0; }
	Graf(vector<CamiBase*> c);
	~Graf();
	void afegirNode(const Coordinate node);
	void afegirAresta(const int pos1,const int pos2);
private:
	vector<list<pair<int, float>>> m_veins;
	vector<Coordinate> m_nodes;
	int m_numNodes;
	int m_numArestes;
	const int distMax = 10000000;
};