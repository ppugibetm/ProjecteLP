#pragma once
#include "PuntDeInteresBase.h"

using namespace std;

class PuntDeInteresRestaurantSolucio : public PuntDeInteresBase {
public:
	PuntDeInteresRestaurantSolucio() : m_cuisine(""), m_wheelchair("") {}
	PuntDeInteresRestaurantSolucio* clone() { return new PuntDeInteresRestaurantSolucio(*this); }
	PuntDeInteresRestaurantSolucio(PuntDeInteresRestaurantSolucio& restaurant) : PuntDeInteresBase(restaurant.getCoord(), restaurant.getName()), m_cuisine(restaurant.m_cuisine) {}
	PuntDeInteresRestaurantSolucio(const Coordinate& c, const string& n, const string& t, const bool& w) : PuntDeInteresBase(c, n), m_cuisine(t), m_wheelchair(w) {}
	~PuntDeInteresRestaurantSolucio() {}
	string getName() { return PuntDeInteresBase::getName(); }
	unsigned int getColor() {
		if (m_cuisine == "pizza" && m_wheelchair)
			return 0x03FCBA;
		else if (m_cuisine == "chinese")
			return 0xA6D9F7;
		else if (m_wheelchair)
			return 0x251351;
		else
			return PuntDeInteresBase::getColor();
	}
	void setWheelchair(bool w) { m_wheelchair = w; }
	void setCuisine(string c) { m_cuisine = c; }
	void setAmenity(const string amenity) { m_amenity = amenity; }

	void setName(string n) { PuntDeInteresBase::setName(n); }
	void setCoord(Coordinate c) { PuntDeInteresBase::setCoord(c); }
private:
	string m_cuisine;
	string m_amenity;
	bool m_wheelchair;
};