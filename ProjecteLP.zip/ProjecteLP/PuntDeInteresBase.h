#pragma once

#include <string>
#include "Common.h"

using namespace std;

class PuntDeInteresBase {

	protected:
		Coordinate m_coord;
		std::string m_name;
	public:		
		PuntDeInteresBase();
		PuntDeInteresBase(Coordinate coord, std::string name);

		virtual std::string getName();
		Coordinate getCoord();
		virtual unsigned int getColor();

};

class PuntDeInteresBotigaSolucio: public PuntDeInteresBase {
public:
	PuntDeInteresBotigaSolucio(PuntDeInteresBotigaSolucio& botiga) : PuntDeInteresBase(botiga.getCoord(), botiga.getName()), m_shop(botiga.m_shop) {}
	PuntDeInteresBotigaSolucio(const Coordinate& c, const string& n, const string& t) : PuntDeInteresBase(c, n), m_shop(t) {}
	~PuntDeInteresBotigaSolucio() {}
	string getName() { return PuntDeInteresBase::getName(); }
	unsigned int getColor() {
		if (m_shop == "supermarket")
			return 0xA5BE00;
		else if (m_shop == "tobacco")
			return 0xFFAD69;
		else if (m_shop == "bakery")
		{
			if (m_opening_hours && m_wheelchair)
				return 0x4CB944;
			else
				return 0xE85D75;
		}
		else
			return 0xFFA550;
	}
private:
	string m_shop;
	bool m_opening_hours;
	bool m_wheelchair;
};

class PuntDeInteresRestaurantSolucio: public PuntDeInteresBase {
public:
	PuntDeInteresRestaurantSolucio(PuntDeInteresRestaurantSolucio& restaurant) : PuntDeInteresBase(restaurant.getCoord(), restaurant.getName()), m_cuisine(restaurant.m_cuisine) {}
	PuntDeInteresRestaurantSolucio(const Coordinate& c, const string& n, const string& t, const bool& w) : PuntDeInteresBase(c, n), m_cuisine(t), m_wheelchair(w) {}
	~PuntDeInteresRestaurantSolucio() {}
	string getName() { return PuntDeInteresBase::getName(); }
	unsigned int getColor() {
		if (m_wheelchair == true)
			return 0x251351;
		else if (m_cuisine == "pizza")
			return 0x03FCBA;
		else if (m_cuisine == "chinese")
			return 0xA6D9F7;
		else
			PuntDeInteresBase::getColor();
	}
private:
	string m_cuisine;
	bool m_wheelchair;
};