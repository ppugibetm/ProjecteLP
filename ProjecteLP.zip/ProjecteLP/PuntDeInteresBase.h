#pragma once

#include "Common.h"

using namespace std;

class PuntDeInteresBase {

private:
	Coordinate m_coord;
	std::string m_name;

public:
	PuntDeInteresBase();
	PuntDeInteresBase(Coordinate coord, std::string name);

	virtual std::string getName();
	Coordinate getCoord();
	virtual unsigned int getColor();

	void setName(string n) { m_name = n; }
	void setCoord(Coordinate c) { m_coord = c; }
};
