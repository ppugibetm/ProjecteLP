#pragma once

#include <string>
#include "Common.h"

using namespace std;

class PuntDeInteresBase {

	protected:
		Coordinate m_coord;
		std::string m_name;
	public:		
		PuntDeInteresBase();
		PuntDeInteresBase(Coordinate coord, std::string name);
		PuntDeInteresBase(PuntDeInteresBase& p) : m_coord(p.m_coord), m_name(p.m_name) {}

		virtual std::string getName();
		Coordinate getCoord();
		virtual unsigned int getColor();
		void setCoord(Coordinate c) { m_coord = c; }
		void setName(string n) { m_name = n; }
		PuntDeInteresBase* clone() { return new PuntDeInteresBase(*this); }
};

class PuntDeInteresBotigaSolucio: public PuntDeInteresBase {
public:
	PuntDeInteresBotigaSolucio() : m_shop(""), m_wheelchair(""), m_opening_hours("") {}
	PuntDeInteresBotigaSolucio* clone() { return new PuntDeInteresBotigaSolucio(*this); }
	PuntDeInteresBotigaSolucio(PuntDeInteresBotigaSolucio& botiga) : PuntDeInteresBase(botiga.getCoord(), botiga.getName()), m_shop(botiga.m_shop) {}
	PuntDeInteresBotigaSolucio(const Coordinate& c, const string& n, const string& t) : PuntDeInteresBase(c, n), m_shop(t) {}
	~PuntDeInteresBotigaSolucio() {}
	string getName() { return PuntDeInteresBase::getName(); }
	unsigned int getColor() {
		if (m_shop == "bakery" && m_wheelchair && m_opening_hours)
			return 0x4CB944;
		else if (m_shop == "bakery")
			return 0xE85D75;
		else if (m_shop == "supermarket")
			return 0xA5BE00;
		else if (m_shop == "tobacco")
			return 0xFFAD69;
		return PuntDeInteresBase::getColor();
	}
	void setWheelchair(bool w) { m_wheelchair = w; }
	void setOpeningHours(bool oh) { m_opening_hours = oh; }
	void setShop(string s) { m_shop = s; }
private:
	string m_shop;
	bool m_opening_hours;
	bool m_wheelchair;
};

class PuntDeInteresRestaurantSolucio: public PuntDeInteresBase {
public:
	PuntDeInteresRestaurantSolucio() : m_cuisine(""), m_wheelchair("") {}
	PuntDeInteresRestaurantSolucio* clone() { return new PuntDeInteresRestaurantSolucio(*this); }
	PuntDeInteresRestaurantSolucio(PuntDeInteresRestaurantSolucio& restaurant) : PuntDeInteresBase(restaurant.getCoord(), restaurant.getName()), m_cuisine(restaurant.m_cuisine) {}
	PuntDeInteresRestaurantSolucio(const Coordinate& c, const string& n, const string& t, const bool& w) : PuntDeInteresBase(c, n), m_cuisine(t), m_wheelchair(w) {}
	~PuntDeInteresRestaurantSolucio() {}
	string getName() { return PuntDeInteresBase::getName(); }
	unsigned int getColor() {
		if (m_cuisine == "pizza" && m_wheelchair)
			return 0x03FCBA;
		else if (m_cuisine == "chinese")
			return 0xA6D9F7;
		else if (m_wheelchair)
			return 0x251351;
		else
			return PuntDeInteresBase::getColor();
	}
	void setWheelchair(bool w) { m_wheelchair = w; }
	void setCuisine(string c) { m_cuisine = c; }
	void setAmenity(const string amenity) { m_amenity = amenity; }
private:
	string m_cuisine;
	string m_amenity;
	bool m_wheelchair;
};