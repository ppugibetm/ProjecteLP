#pragma once
#include <vector>
#include <list>
#include "Util.h"
#include "CamiBase.h"

using namespace std;

class BallTree
{
public:
	BallTree() { 
		m_left = nullptr, m_right = nullptr;
		Coordinate c;
		c.lat = 0.001;
		c.lon = 0.001;
		m_pivot = c;
		m_radi = 0.0;
	}
	BallTree(BallTree* ball) { construirArbre(ball->m_coordenades); }
	//BallTree(const vector<CamiBase*>& camins);
	~BallTree();

	BallTree* getArrel() { return this; }

	Coordinate getPivot() { return m_pivot; }
	double getRadi() { return m_radi; }
	BallTree* getEsquerre() { return m_left; }
	BallTree* getDreta() { return m_right; }

	vector<Coordinate>& getCoordenades() { return m_coordenades; }

	void construirArbre(const vector<Coordinate>& coordenades);

	Coordinate nodeMesProper(Coordinate targetQuery, Coordinate& Q, BallTree* ball);

	Coordinate trobarPivot(const vector<Coordinate>& coordenades);

	float calcularDistanciaMax(const vector<Coordinate> coordenades, const Coordinate punt, int &index);

	void inOrdre(vector<std::list<Coordinate>>& out);
	void postOrdre(std::vector<std::list<Coordinate>>&out);
	void preOrdre(std::vector<std::list<Coordinate>>& out);
private:
	BallTree* m_left;
	BallTree* m_right;
	Coordinate m_pivot;
	vector<Coordinate> m_coordenades;
	double m_radi;
};