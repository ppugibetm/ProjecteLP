
#include "MapaSolucio.h"

CamiBase * MapaSolucio::buscaCamiMesCurt(PuntDeInteresBase *desde, PuntDeInteresBase *a) {
    return new CamiSolucio;
}
