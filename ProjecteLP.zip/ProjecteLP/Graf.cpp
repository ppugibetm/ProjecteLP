#include "Graf.h"

Graf::Graf(vector<CamiBase*> c)
{
	for (int i = 0; i < c.size(); i++)
	{
		vector<Coordinate> camiCoords = c[i]->getCamiCoords();
		for (int j = 0; j < camiCoords.size(); j++)
		{
			vector<Coordinate>::iterator it = m_nodes.begin();
			bool trobat = false;

			for (it, trobat; it != m_nodes.end() && !trobat; it++)
				if (it->lat == camiCoords[j].lat && it->lon == camiCoords[j].lon)
					trobat = true;
			
			if (it == m_nodes.end())
				m_nodes.emplace_back(camiCoords[j]);
		}
	}

	m_numArestes = 0;
	m_numNodes = m_nodes.size();
	m_veins.resize(m_numNodes);

	for (int i = 0; i < c.size(); i++)
	{
		vector<Coordinate> camiCoords = c[i]->getCamiCoords();
		for (int j = 0; j < camiCoords.size(); j++)
		{
			int pos1 = 0, pos2 = 0;
			for (int k = 0; k < m_numNodes; i++)
				if (m_nodes[k].lat == camiCoords[j].lat && m_nodes[k].lon == camiCoords[j].lon)
					pos1 = k;

			for (int k = 0; k < m_numNodes; i++)
				if (m_nodes[k].lat == camiCoords[j + 1].lat && m_nodes[k].lon == camiCoords[j + 1].lon)
					pos2 = k;

			afegirAresta(pos1, pos2);
		}
	}
}

void Graf::afegirNode(const Coordinate node)
{
	m_numNodes++;
	m_nodes.push_back(node);
	m_veins.resize(m_numNodes);
}

void Graf::afegirAresta(const int pos1, const int pos2)
{
	if ((pos1 < m_numNodes) && (pos2 < m_numNodes) && (pos1 >= 0) && (pos2 >= 0))
	{
		float distancia = Util::DistanciaHaversine(m_nodes[pos1], m_nodes[pos2]);
		m_veins[pos2].emplace_back(pair<int, float>(pos1, distancia));
		m_veins[pos1].emplace_back(pair<int, float>(pos2, distancia));
		m_numArestes++;
	}
}