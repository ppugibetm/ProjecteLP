#pragma once
#include "PuntDeInteresBase.h"

using namespace std;

class PuntDeInteresBotigaSolucio : public PuntDeInteresBase {
public:
	PuntDeInteresBotigaSolucio() : m_shop(""), m_wheelchair(""), m_opening_hours("") {}
	PuntDeInteresBotigaSolucio* clone() { return new PuntDeInteresBotigaSolucio(*this); }
	PuntDeInteresBotigaSolucio(PuntDeInteresBotigaSolucio& botiga) : PuntDeInteresBase(botiga.getCoord(), botiga.getName()), m_shop(botiga.m_shop) {}
	PuntDeInteresBotigaSolucio(const Coordinate& c, const string& n, const string& t, const bool& w, const bool& oh) : PuntDeInteresBase(c, n), m_shop(t), m_wheelchair(w), m_opening_hours(oh) {}
	~PuntDeInteresBotigaSolucio() {}
	string getName() { return PuntDeInteresBase::getName(); }
	unsigned int getColor() {
		if (m_shop == "bakery" && m_wheelchair && m_opening_hours)
			return 0x4CB944;
		else if (m_shop == "bakery")
			return 0xE85D75;
		else if (m_shop == "supermarket")
			return 0xA5BE00;
		else if (m_shop == "tobacco")
			return 0xFFAD69;
		return PuntDeInteresBase::getColor();
	}
	void setWheelchair(bool w) { m_wheelchair = w; }
	void setOpeningHours(bool oh) { m_opening_hours = oh; }
	void setShop(string s) { m_shop = s; }

	void setName(string n) { PuntDeInteresBase::setName(n); }
	void setCoord(Coordinate c) { PuntDeInteresBase::setCoord(c); }
private:
	string m_shop;
	bool m_opening_hours;
	bool m_wheelchair;
};