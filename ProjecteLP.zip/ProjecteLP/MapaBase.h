#pragma once
#include "pch.h"

#include "Common.h"
#include "PuntDeInteresBase.h"
#include "CamiBase.h"


class MapaBase {
	public:
		virtual void getPdis(std::vector<PuntDeInteresBase*>&) = 0;
		virtual void getCamins(std::vector<CamiBase*>&) = 0;
		virtual void parsejaXmlElements(std::vector<XmlElement>& xmlElements) = 0;

};

class MapaSolucio : public MapaBase {
public:
	MapaSolucio() {};

	void getCamins(std::vector<CamiBase*>& camins) {
		CamiSolucio* camiSolucio = new CamiSolucio();
		(*camiSolucio).getCamiCoords();
		camins.push_back(camiSolucio);
	}

	void getPdis(std::vector<PuntDeInteresBase*>& pdis) {
		Coordinate c;
		c.lat = 41.4918606;
		c.lon = 2.1465411;
		PuntDeInteresBase* b = new PuntDeInteresBotigaSolucio(c, "La Millor Pastisseria", "bakery");
		c.lat = 41.4902204;
		c.lon = 2.1406477;
		bool wheelchair = true;
		PuntDeInteresBase* r = new PuntDeInteresRestaurantSolucio(c, "El Millor Restaurant", "regional", wheelchair);
		pdis.push_back(b);
		pdis.push_back(r);
	}

	void parsejaXmlElements(std::vector<XmlElement>& xmlElements)
	{

	}
private:
	vector<PuntDeInteresBase> m_puntsInteres;
	vector<CamiBase> m_camins;
};

