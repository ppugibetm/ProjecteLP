#pragma once

#include "Common.h"
#include <vector>

class CamiBase {
	public:
		virtual std::vector<Coordinate> getCamiCoords() = 0;
};

class CamiSolucio: public CamiBase {
public:
	CamiSolucio() {}
	~CamiSolucio() {}
	std::vector<Coordinate> getCamiCoords() {
		vector<double> lats { 41.4928803, 41.4929072, 41.4933070, 41.4939882 };
		vector<double> lons { 2.1452381, 2.1452474, 2.1453852, 2.1456419 };
		vector<Coordinate> v;
		for (int i = 0; i < 4; i++)
		{
			Coordinate c;
			c.lat = lats[i];
			c.lon = lons[i];
			v.push_back(c);
		}
		return v;
	}

private:
	vector<Coordinate> m_Coordinates;
};