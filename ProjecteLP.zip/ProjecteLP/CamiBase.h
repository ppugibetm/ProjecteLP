#pragma once

#include "Common.h"
#include <vector>

class CamiBase {
	public:
		CamiBase() {}
		CamiBase(CamiBase&) {}
		virtual CamiBase* clone() = 0;
		virtual std::vector<Coordinate> getCamiCoords() = 0;
};

class CamiSolucio: public CamiBase {
public:
	CamiSolucio() {}
	~CamiSolucio() {}
	std::vector<Coordinate> getCamiCoords() {
		return m_coordinates;
	}
	CamiSolucio* clone() { return new CamiSolucio(*this); }
	void addCoords(Coordinate c) { m_coordinates.push_back(c); }
	void setCami(vector<Coordinate> coords) { m_coordinates = coords; }
	void setHighway(const string hw) { m_highway = hw == "yes"; }
private:
	vector<Coordinate> m_coordinates;
	bool m_highway;
};