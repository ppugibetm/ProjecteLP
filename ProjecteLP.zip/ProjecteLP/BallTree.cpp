#include "BallTree.h"
#include "pch.h"

BallTree::BallTree(const vector<CamiBase*>& camins)
{
    
}

void BallTree::construirArbre(const std::vector<Coordinate>& coordenades) {
    if (coordenades.empty()) return;

    m_coordenades = coordenades;

    m_pivot = trobarPivot(coordenades);

    int indexA;
    float distanciaA = calcularDistanciaMax(coordenades, m_pivot, indexA);
    m_radi = distanciaA;

    if (coordenades.size() > 1)
    {
        int indexB;
        float distanciaB = calcularDistanciaMax(coordenades, coordenades[indexA], indexB);

        vector<Coordinate> vecEsq, vecDret;
        for (int i = 0; i < coordenades.size(); i++)
        {
            float dist1 = Util::DistanciaHaversine(coordenades[i], coordenades[indexA]);
            float dist2 = Util::DistanciaHaversine(coordenades[i], coordenades[indexB]);

            if (dist1 > dist2)
                vecEsq.emplace_back(coordenades[i]);
            else
                vecDret.emplace_back(coordenades[i]);

            m_left = new BallTree;
            m_left->construirArbre(vecEsq);
            m_right = new BallTree;
            m_right->construirArbre(vecDret);
        }
    }
}

float BallTree::calcularDistanciaMax(vector<Coordinate> coordenades, Coordinate punt, int& index)
{
    float distanciaMax = Util::DistanciaHaversine(coordenades[0], m_pivot);

    for (int i = 0; i < coordenades.size(); i++)
    {
        float aux = Util::DistanciaHaversine(coordenades[i], m_pivot);
        if (distanciaMax < aux)
        {
            distanciaMax = aux;
            index = i;
        }
    }

    return distanciaMax;
}

Coordinate BallTree::trobarPivot(const vector<Coordinate>& coordenades)
{
    float latMax = coordenades.front().lat;
    float latMin = coordenades.front().lat;
    float lonMax = coordenades.front().lon;
    float lonMin = coordenades.front().lon;

    for (int i = 0; i < coordenades.size(); i++)
    {
        latMin = min(latMin, coordenades[i].lat);
        latMax = max(latMax, coordenades[i].lat);
        lonMin = min(lonMin, coordenades[i].lon);
        lonMax = max(lonMax, coordenades[i].lon);
    }

    Coordinate pivot;
    pivot.lat = (latMin + latMax) / 2;
    pivot.lon = (lonMin + lonMax) / 2;

    return pivot;
}

void BallTree::inOrdre(std::vector<std::list<Coordinate>>& out) {
    if (m_left != nullptr)
        m_left->inOrdre(out);

    list<Coordinate> llista_coordenades(m_coordenades.begin(), m_coordenades.end());
    out.push_back(llista_coordenades);

    if (m_right != nullptr)
        m_right->inOrdre(out);
}

void BallTree::preOrdre(std::vector<std::list<Coordinate>>& out) {
    list<Coordinate> llista_coordenades(m_coordenades.begin(), m_coordenades.end());
    out.push_back(llista_coordenades);

    if (m_left != nullptr)
        m_left->preOrdre(out);

    if (m_right != nullptr)
        m_right->preOrdre(out);
}

void BallTree::postOrdre(std::vector<std::list<Coordinate>>& out) {
    if (m_left != nullptr)
        m_left->postOrdre(out);

    if (m_right != nullptr)
        m_right->postOrdre(out);

    list<Coordinate> llista_coordenades(m_coordenades.begin(), m_coordenades.end());
    out.push_back(llista_coordenades);
}

Coordinate BallTree::nodeMesProper(Coordinate targetQuery, Coordinate& Q, BallTree* ball) {
    if (ball == nullptr) //devuelve Q si el arbol est� vac�o
        return Q;

    float distancia = Util::DistanciaHaversine(targetQuery, ball->m_pivot);
    
    if (distancia < Util::DistanciaHaversine(targetQuery, Q))
        Q = ball->m_pivot;

    if (targetQuery.lat - Q.lat <= ball->m_radi && targetQuery.lon - Q.lon <= ball->m_radi) //Si la distancia entre la coordenada de b�squeda y la coordenada del nodo es menor que la distancia entre la coordenada de b�squeda y la coordenada del nodo m�s cercano hasta el momento , se actualiza la coordenada del nodo m�s cercano con la coordenada del nodo actual.
    {
        Q = nodeMesProper(targetQuery, Q, ball->m_left);
        Q = nodeMesProper(targetQuery, Q, ball->m_right);
    }
    else if (targetQuery.lat - ball->m_pivot.lat > 0)
        Q = nodeMesProper(targetQuery, Q, ball->m_right);
    else
        Q = nodeMesProper(targetQuery, Q, ball->m_left);

    return Q;
}

