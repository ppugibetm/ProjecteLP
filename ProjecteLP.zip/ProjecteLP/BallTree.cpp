#include "BallTree.h"
#include "pch.h"


void BallTree::construirArbre(const vector<Coordinate>& coordenades) 
{
    if (coordenades.size() == 1)
    {
        m_radi = 0;
        m_coordenades = coordenades;
        m_pivot = m_coordenades[0];
        return;
    }

    m_coordenades = coordenades;
    m_pivot = Util::calcularPuntCentral(m_coordenades);

    int indexA;
    float distanciaA = calcularDistanciaMax(coordenades, m_pivot, indexA);
    m_radi = distanciaA;

    if (coordenades.size() > 1)
    {
        int indexB;
        float distanciaB = calcularDistanciaMax(coordenades, coordenades[indexA], indexB);

        vector<Coordinate> vecEsq, vecDret;
        for (int i = 0; i < coordenades.size(); i++)
        {
            float dist1 = Util::DistanciaHaversine(coordenades[i], coordenades[indexA]);
            float dist2 = Util::DistanciaHaversine(coordenades[i], coordenades[indexB]);

            if (dist1 > dist2)
                vecEsq.emplace_back(coordenades[i]);
            else
                vecDret.emplace_back(coordenades[i]);
        }

        if (vecEsq.size() > 0)
        {
            m_left = new BallTree();
            m_left->construirArbre(vecEsq);
        }

        if (vecDret.size() > 0)
        {
            m_right = new BallTree();
            m_right->construirArbre(vecDret);
        }
    }
}

float BallTree::calcularDistanciaMax(vector<Coordinate> coordenades, Coordinate punt, int& index)
{
    float distanciaMax = Util::DistanciaHaversine(coordenades[0], punt);
    index = 0;

    for (int i = 1; i < coordenades.size(); i++)
    {
        float aux = Util::DistanciaHaversine(coordenades[i], punt);
        if (distanciaMax < aux)
        {
            distanciaMax = aux;
            index = i;
        }
    }

    return distanciaMax;
}

void BallTree::inOrdre(std::vector<std::list<Coordinate>>& out) {
    if (m_right != nullptr)
        m_right->inOrdre(out);

    list<Coordinate> llista_coordenades(m_coordenades.begin(), m_coordenades.end());
    out.push_back(llista_coordenades);

    if (m_left != nullptr)
        m_left->inOrdre(out);
}

void BallTree::preOrdre(std::vector<std::list<Coordinate>>& out) {
    list<Coordinate> llista_coordenades(m_coordenades.begin(), m_coordenades.end());
    out.push_back(llista_coordenades);

    if (m_right != nullptr)
        m_right->preOrdre(out);

    if (m_left != nullptr)
        m_left->preOrdre(out);
}

void BallTree::postOrdre(std::vector<std::list<Coordinate>>& out) {
    if (m_right != nullptr)
        m_right->postOrdre(out);

    if (m_left != nullptr)
        m_left->postOrdre(out);

    list<Coordinate> llista_coordenades(m_coordenades.begin(), m_coordenades.end());
    out.push_back(llista_coordenades);
}

Coordinate BallTree::nodeMesProper(Coordinate targetQuery, Coordinate& Q, BallTree* ball) {
    if (ball == nullptr) //devuelve Q si el arbol est� vac�o
        return Q;

    float distancia = Util::DistanciaHaversine(targetQuery, ball->m_pivot);
    
    if (distancia < Util::DistanciaHaversine(targetQuery, Q))
        Q = ball->m_pivot;

    if (targetQuery.lat - Q.lat <= ball->m_radi && targetQuery.lon - Q.lon <= ball->m_radi) //Si la distancia entre la coordenada de b�squeda y la coordenada del nodo es menor que la distancia entre la coordenada de b�squeda y la coordenada del nodo m�s cercano hasta el momento , se actualiza la coordenada del nodo m�s cercano con la coordenada del nodo actual.
    {
        Q = nodeMesProper(targetQuery, Q, ball->m_left);
        Q = nodeMesProper(targetQuery, Q, ball->m_right);
    }
    else if (targetQuery.lat - ball->m_pivot.lat > 0)
        Q = nodeMesProper(targetQuery, Q, ball->m_right);
    else
        Q = nodeMesProper(targetQuery, Q, ball->m_left);

    return Q;
}

