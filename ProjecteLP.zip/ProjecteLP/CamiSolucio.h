#include "CamiBase.h"
#include <vector>
using namespace std;

class CamiSolucio : public CamiBase {
public:
	CamiSolucio() { m_highway = false; }
	~CamiSolucio() {}
	std::vector<Coordinate> getCamiCoords() {
		return m_coordinates;
	}
	CamiSolucio* clone() { return new CamiSolucio(*this); }
	void addCoords(Coordinate c) { m_coordinates.push_back(c); }
	void setCami(vector<Coordinate> coords) { m_coordinates = coords; }
	void setHighway(const string hw) { m_highway = hw == "yes"; }
private:
	vector<Coordinate> m_coordinates;
	bool m_highway;
};